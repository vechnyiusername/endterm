public abstract class RecipeFactory {
    public abstract Recipe createRecipe(String name);
}
